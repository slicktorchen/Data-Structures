HOMEWORK 2: TENNIS CLASSES


NAME:  Victor Chen
RIN: 661291944


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

Some awesome person at Tuesday TA office hours (6-8)

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  25 hours



DESCRIPTION OF 3RD STATISTIC:
The third statistic calculates the number of tiebreak wins and losses for each player and calculates the percentage
of tiebreaker wins when a player plays tiebreaker games. A tiebreak game is identified if one of the number of games won or lost
in a set is equal to 7. If a player has never played a tiebreak game, then a percentage is unable to be calculated and "N/A" is printed instead.



RESULTS FROM 3RD STATISTIC:

Input:
Marcos Baghdatis d. Radek Stepanek  6-4 6-3 3-6 0-6 7-5
David Nalbandian d. Danai Udomchoke  6-2 6-2 1-6 6-7 6-1
Marcos Baghdatis d. Ivan Ljubicic  6-4 6-2 4-6 3-6 6-3
Marcos Baghdatis d. David Nalbandian  3-6 5-7 6-3 6-4 6-4

Output:
TIEBREAK STATISTICS
Player              W    L   percentage
Danai Udomchoke     1    0        1.000
David Nalbandian    0    1        0.000
Marcos Baghdatis    0    0          N/A
Ivan Ljubicic       0    0          N/A
Radek Stepanek      0    0          N/A

MISC. COMMENTS TO GRADER:  
Optional, please be concise!


